# Red Rover

- **Portfolio group:** Engineering
- **Portfolio page:** `#/project/red-rover`
- **Site content:** `src/content/portfolio.json` (project with the matching name)

## Source links
- CMU Box (all project files, requires CMU login): https://cmu.box.com/s/9ndyk7qp4fkcdqi81q2uylwpihclj3kx
-

## Files
Drop working files in `files/` (CAD, sketches, photos, PDFs, docs). Nothing in `boards/` is part of the website build.

## Brief
<!-- Your own words: what this project is. -->

## Status / next steps
-

## Notes and decisions
-
